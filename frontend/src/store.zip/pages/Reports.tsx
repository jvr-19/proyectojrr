import React from 'react'
import '../App.css';
import Menus from '../components/Menu';


function Reports() {

  return (
    <>
      <Menus />
    </>
  )
}

export default Reports
