import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import '../App.css';
import Container from '@mui/material/Container';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid2';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import LockIcon from '@mui/icons-material/Lock';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import TextField from '@mui/material/TextField';
import Alert from '@mui/material/Alert';

//Importamos el useDispatch del react-redux
import { useDispatch } from 'react-redux'
//Importamos las acciones que están en el fichero authSlice.ts
import { authActions } from '../store/authSlice';

function Login() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const [attempted, setAttempted] = useState(false);
  const [enabled, setEnabled] = useState(false)
  const [data, setData] = useState({ user: '', passwd: '' })
  const [errorMessage, setErrorMessage] = useState(null)

  // Función de verificación de usuario
  async function isVerifiedUser() {
    try {
      const response = await fetch(`http://localhost:3030/login?user=${data.user}&password=${data.passwd}`)
      const result = await response.json()

      console.log('Lo que nos llega de la base de datos: ', result.data)

      if (result.data.length !== 0) {
        // Si hay datos, usuario y contraseña son correctos
        dispatch(authActions.login({ user: data.user })) // Dispatch login action
        navigate('/home') // Navegación a página principal o de bienvenida
      } else {
        // Si no, alertar al usuario sobre credenciales incorrectas
        setErrorMessage('Usuario o contraseña incorrectos.')
      }
    } catch (error) {
      console.error("Error en la autenticación: ", error)
      setErrorMessage("Error en la autenticación, intente nuevamente.")
    }
  }

  const handleSubmit = (event) => {
    event.preventDefault()
    setAttempted(true)
    isVerifiedUser()
  }

  return (
    <Container component="main" maxWidth="xs">
      <Paper elevation={3} className="login-paper">
        <Box display="flex" flexDirection="column" alignItems="center" p={3}>
          <LockIcon />
          <Typography component="h1" variant="h5">
            Iniciar Sesión
          </Typography>
          <form onSubmit={handleSubmit}>
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="user"
              label="Usuario"
              name="user"
              autoComplete="user"
              autoFocus
              value={data.user}
              onChange={(e) => setData({ ...data, user: e.target.value })}
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              name="passwd"
              label="Contraseña"
              type="password"
              id="passwd"
              autoComplete="current-password"
              value={data.passwd}
              onChange={(e) => setData({ ...data, passwd: e.target.value })}
            />
            {errorMessage && (
              <Alert severity="error">{errorMessage}</Alert>
            )}
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              disabled={!enabled}
            >
              Iniciar Sesión
            </Button>
          </form>
        </Box>
      </Paper>
    </Container>
  );
}

export default Login;